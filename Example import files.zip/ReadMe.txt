These files are examples of the kinds of images you can import into Undiscovered Worlds to create custom worlds. These are based on maps of Tolkien�s Arda found here: https://imgur.com/a/STOyt

There are three files here - one for the land, one for the mountains, and one for the volcanoes. (You can also import sea files too, but it�s not essential.)

You can import these yourself into UW to create your own Tolkien maps, or examine them to see how to create your own.
